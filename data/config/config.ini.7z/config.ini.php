<?php
if (!defined('IN_XIAOCMS')) exit();
return array (
  'site_name' => '济南玲雨机械制造有限公司',
  'site_theme' => 'shengjiangji',
  'site_mobile' => '0',
  'wap' => '',
  'site_title' => '济南玲雨机械制造有限公司',
  'site_keywords' => '',
  'site_description' => '',
  'site_baidusub' => '',
  'site_status' => '1|正常
2|头条
3|推荐
4|首页幻灯
0|未审核',
  'site_download_image' => '1',
  'site_watermark' => '0',
  'site_watermark_pos' => '5',
  'member_modelid' => '5',
  'qq_login' => '0',
  'appid' => '',
  'appkey' => '',
  'member_register' => '0',
  'member_status' => '1',
  'member_regcode' => '1',
  'member_logincode' => '1',
  'diy_url' => '1',
  'list_url' => '{catdir}/',
  'list_page_url' => '{catdir}/list_{page}.html',
  'show_url' => '{catdir}/{id}.html',
  'show_page_url' => '{catdir}/{id}_{page}.html',
  'smtpserver' => 'smtp.163.com',
  'smtpserverport' => '25',
  'smtpusermail' => '',
  'smtpuser' => 'admin',
  'smtppass' => 'admin',
  'smtpemailto' => '',
  'rand_code' => '66525ce6abb23ffb116b760ab8a0ca76',
);